Proyecto de optimizacion



Evidencia para progreso en fechas:
Benjamín Horta:

![image](https://github.com/user-attachments/assets/9ba0ceaa-f839-46e1-b779-a7c67ce885b1)


José Flores:

![image](https://github.com/user-attachments/assets/976443ae-5aa9-4077-82ae-c533fc8a8df6)


![image](https://github.com/user-attachments/assets/dddb1e5f-2703-4df4-a3ca-6a4c57cfb0b2)
