#include "input.h"
#include "ui_input.h"

Input::Input(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Input)
{
    ui->setupUi(this);
}

Input::~Input()
{
    delete ui;
}
